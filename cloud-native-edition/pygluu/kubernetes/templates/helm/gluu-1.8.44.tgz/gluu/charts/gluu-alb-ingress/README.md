# gluu-alb-ingress

![Version: 1.8.44](https://img.shields.io/badge/Version-1.8.44-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: 4.5.8](https://img.shields.io/badge/AppVersion-4.5.8-informational?style=flat-square)

Nginx ingress definitions chart

**Homepage:** <https://gluu.org/docs/gluu-server>

## Maintainers

| Name | Email | Url |
| ---- | ------ | --- |
| Mohammad Abudayyeh | <support@gluu.org> | <https://github.com/moabu> |

## Source Code

* <https://docs.aws.amazon.com/eks/latest/userguide/alb-ingress.html>
* <https://kubernetes.io/docs/concepts/services-networking/ingress/>
* <https://github.com/GluuFederation/gluu4/tree/4.5/cloud-native-edition>

## Requirements

Kubernetes: `>=v1.22.0-0`

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| ingress | object | `{"additionalAnnotations":{},"additionalLabels":{},"adminUiEnabled":true,"authServerEnabled":true,"casaEnabled":true,"enabled":true,"fido2ConfigEnabled":false,"fido2Enabled":false,"openidConfigEnabled":true,"passportEnabled":false,"scimConfigEnabled":false,"scimEnabled":false,"shibEnabled":false,"u2fConfigEnabled":true,"uma2ConfigEnabled":true,"webdiscoveryEnabled":true,"webfingerEnabled":true}` | ALB ingress definitions chart |
| ingress.additionalAnnotations | object | `{}` | Additional annotations that will be added across all ingress definitions in the format of {cert-manager.io/issuer: "letsencrypt-prod"} |
| ingress.additionalLabels | object | `{}` | Additional labels that will be added across all ingress definitions in the format of {mylabel: "myapp"} |
| ingress.adminUiEnabled | bool | `true` | Enable Admin UI endpoints /identity |
| ingress.authServerEnabled | bool | `true` | Enable Auth server endpoints /oxauth |
| ingress.casaEnabled | bool | `true` | Enable casa endpoints /casa |
| ingress.fido2ConfigEnabled | bool | `false` | Enable endpoint /.well-known/fido2-configuration |
| ingress.fido2Enabled | bool | `false` | Enable  all fido2 endpoints /fido2 |
| ingress.openidConfigEnabled | bool | `true` | Enable endpoint /.well-known/openid-configuration |
| ingress.passportEnabled | bool | `false` | Enable passport /passport |
| ingress.scimConfigEnabled | bool | `false` | Enable endpoint /.well-known/scim-configuration |
| ingress.scimEnabled | bool | `false` | Enable SCIM endpoints /scim |
| ingress.shibEnabled | bool | `false` | Enable  oxshibboleth endpoints /idp |
| ingress.u2fConfigEnabled | bool | `true` | Enable endpoint /.well-known/fido-configuration |
| ingress.uma2ConfigEnabled | bool | `true` | Enable endpoint /.well-known/uma2-configuration |
| ingress.webdiscoveryEnabled | bool | `true` | Enable endpoint /.well-known/simple-web-discovery |
| ingress.webfingerEnabled | bool | `true` | Enable endpoint /.well-known/webfinger |
